<?php
//�û��ڵ�¼ǰ�ж��Ƿ���session�б����
session_start();
header("Content-Type:application/json;charset=utf-8");
require("init.php");
@$uid=$_SESSION["uid"];
if($uid){
    $sql="select uname from pk_user where uid=$uid";
    $uname=sql_execute($sql)[0]["uname"];
    echo '{"code":1,"uname":"'.$uname.'"}';
   }else{
    echo '{"code":-1,"uname":""}';
   }