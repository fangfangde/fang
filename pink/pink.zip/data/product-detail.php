 <?php
header("Content-Type:application/json;charset=utf-8");
require("init.php");
// 查询： 需要 lid  md sm lg 图片  from pk_product_pic* from pk_product spec 需要fid 
$output=[];   
$pid=$_REQUEST["pid"];
$sql="select * from pk_product where pid=$pid";
$result=sql_execute($sql);
//var_dump($result);
$output["data"]=$result[0];
$fid=$output["data"]["fid"];
$sql="select * from pk_product_pic where fid=$fid";
$result=sql_execute($sql);
$output["pic"]=$result;
$sql="select pid,spec from pk_product where fid=$fid";
$result=sql_execute($sql);
$output["spec"]=$result;
$sql="select * from pk_recom";
$result=sql_execute($sql);
//var_dump($output);
$output['recom']=$result;
echo json_encode($output);

 







