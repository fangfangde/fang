<?php
session_start();
header("Content-Type:application/json;charset=utf-8");
require("init.php");
@$uid=$_SESSION["uid"];
@$pid=$_REQUEST["pid"];
@$count=$_REQUEST["count"];
$sql="select * from pk_shoppingcart_item where pid=$pid and uid=$uid";
$result=sql_execute($sql);
if(count($result)==0){
	$sql="insert into pk_shoppingcart_item values(null,$uid,$pid,$count,false)";
}else{
	$sql="update pk_shoppingcart_item set count=count+$count where uid=$uid and pid=$pid";
}
$se_result=sql_execute($sql);
if($se_result){
	echo '{"code":1,"msg":"成功"}';
}else{
	echo '{"code":-1,"msg":"失败"}';
}

